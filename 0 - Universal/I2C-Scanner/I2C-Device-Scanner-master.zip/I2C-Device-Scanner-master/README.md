# I2C-Device-Scanner
A programme for I2C Devices that finds and displays the address of the device

Typical output:

I2C Scanner
SDA Pin = 12
SCL Pin = 14

Scanning...I2C device found at address 0x77 !Done.

Scanning...I2C device found at address 0x77 !Done.

